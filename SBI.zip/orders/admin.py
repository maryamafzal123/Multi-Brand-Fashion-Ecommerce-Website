from django.contrib import admin
from django.utils.html import format_html
from .models import Order, OrderItem


class OrderItemInline(admin.TabularInline):
    model           = OrderItem
    extra           = 0
    readonly_fields = ['name', 'price', 'quantity', 'subtotal']
    can_delete      = False

    def subtotal(self, obj):
        return f"Rs. {obj.subtotal:,.0f}"
    subtotal.short_description = 'Subtotal'


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display    = [
        'id', 'user', 'status', 'payment_method',
        'payment_status', 'formatted_total', 'created_at'
    ]
    list_filter     = ['status', 'payment_method', 'payment_status']
    search_fields   = ['user__email', 'user__full_name', 'id']
    list_editable   = ['status']
    readonly_fields = ['subtotal', 'total', 'created_at', 'updated_at']
    inlines         = [OrderItemInline]

    def formatted_total(self, obj):
        return format_html('<strong>Rs. {:,.0f}</strong>', obj.total)
    formatted_total.short_description = 'Total'

    # Optimized admin queryset — no N+1
    def get_queryset(self, request):
        return (
            super().get_queryset(request)
            .select_related('user', 'shipping_address')
            .prefetch_related('items')
        )